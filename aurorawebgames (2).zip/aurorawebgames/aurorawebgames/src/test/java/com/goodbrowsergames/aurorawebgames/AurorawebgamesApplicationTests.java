package com.goodbrowsergames.aurorawebgames;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AurorawebgamesApplicationTests {

	@Test
	void contextLoads() {
	}

}
