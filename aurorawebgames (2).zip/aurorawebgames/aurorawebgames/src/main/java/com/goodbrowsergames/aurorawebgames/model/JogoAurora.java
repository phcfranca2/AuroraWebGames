package com.goodbrowsergames.aurorawebgames.model;

import java.util.Date;
import java.util.Objects;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
public class JogoAurora {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long cdJogo;

    @NotEmpty(message = "O nome do jogo deve ser informado!")
    private String nmJogo;

    @NotEmpty(message = "A categoria do jogo deve ser informado!")
    private String nmCategoriaJogo;

    @NotEmpty(message = "Informe a data de lançamento do jogo!")
    private String dtLancJogo;

    private byte[] imgJogo;

    private String vdApresentaJogo;

    @NotEmpty(message = "Informe a rota de acesso ao jogo!")
    private String linkJogo;

    private boolean fgAtivo;


    public Long getCdJogo() {
        return cdJogo;
    }

    public void setCdJogo(Long cdJogo) {
        this.cdJogo = cdJogo;
    }

    public String getNmJogo() {
        return nmJogo;
    }

    public void setNmJogo(String nmJogo) {
        this.nmJogo = nmJogo;
    }

    public String getNmCategoriaJogo() {
        return nmCategoriaJogo;
    }

    public void setNmCategoriaJogo(String nmCategoriaJogo) {
        this.nmCategoriaJogo = nmCategoriaJogo;
    }

    public String getDtLancJogo() {
        return dtLancJogo;
    }

    public void setDtLancJogo(String dtLancJogo) {
        this.dtLancJogo = dtLancJogo;
    }

    public byte[] getImgJogo() {
        return imgJogo;
    }

    public void setImgJogo(byte[] imgJogo) {
        this.imgJogo = imgJogo;
    }

    public String getVdApresentaJogo() {
        return vdApresentaJogo;
    }

    public void setVdApresentaJogo(String vdApresentaJogo) {
        this.vdApresentaJogo = vdApresentaJogo;
    }

    public String getLinkJogo() {
        return linkJogo;
    }

    public void setLinkJogo(String linkJogo) {
        this.linkJogo = linkJogo;
    }    

    public Boolean getFgAtivo() {
        return fgAtivo;
    }

    public void setFgAtivo(Boolean fgAtivo) {
        this.fgAtivo = fgAtivo;
    }
}
