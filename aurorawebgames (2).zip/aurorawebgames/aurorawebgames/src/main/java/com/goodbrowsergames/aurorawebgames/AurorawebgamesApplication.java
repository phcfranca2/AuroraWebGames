package com.goodbrowsergames.aurorawebgames;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AurorawebgamesApplication {

	public static void main(String[] args) {
		SpringApplication.run(AurorawebgamesApplication.class, args);
	}

}
