package com.goodbrowsergames.aurorawebgames.repository;

import com.goodbrowsergames.aurorawebgames.model.JogoAurora;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface JogosAurora extends JpaRepository<JogoAurora, Long>{
    
}
