package com.goodbrowsergames.aurorawebgames.repository;

import com.goodbrowsergames.aurorawebgames.model.CategoriaJogo;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface CategoriasJogo extends JpaRepository<CategoriaJogo, Long>{
    
}
