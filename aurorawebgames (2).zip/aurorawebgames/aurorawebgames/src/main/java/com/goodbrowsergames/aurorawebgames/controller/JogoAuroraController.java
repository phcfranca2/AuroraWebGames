package com.goodbrowsergames.aurorawebgames.controller;

import java.util.List;
import java.util.function.Function;

import com.goodbrowsergames.aurorawebgames.model.JogoAurora;
import com.goodbrowsergames.aurorawebgames.repository.JogosAurora;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;

import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;


@RestController
@RequestMapping({"/aurorajogos"})
public class JogoAuroraController {
    
    private JogosAurora repositorio;

    JogoAuroraController(JogosAurora jogosAurora) {
        this.repositorio = jogosAurora;
    }

    @GetMapping
    public List getAllAuroraJogos() {
        return repositorio.findAll();
    }

    @GetMapping(path = {"/{id}"})
    public ResponseEntity findAuroraJogosById(@PathVariable long id) {
        return repositorio.findById(id).map(record -> ResponseEntity.ok().body(record))
            .orElse(ResponseEntity.notFound().build());
    }

    @PostMapping
    public JogoAurora create(@RequestBody JogoAurora jogoAurora) {
        return repositorio.save(jogoAurora);
    }

    @PutMapping(value="editar/{id}")
    public ResponseEntity update(@PathVariable ("id") long id, @RequestBody JogoAurora jogoAurora) {
        return repositorio.findById(id)
            .map(record -> {
                record.setDtLancJogo(jogoAurora.getDtLancJogo());
                record.setFgAtivo(jogoAurora.getFgAtivo());
                record.setImgJogo(jogoAurora.getImgJogo());
                record.setLinkJogo(jogoAurora.getLinkJogo());
                record.setNmCategoriaJogo(jogoAurora.getNmCategoriaJogo());
                record.setNmJogo(jogoAurora.getNmJogo());
                record.setVdApresentaJogo(jogoAurora.getVdApresentaJogo());
                JogoAurora update = repositorio.save(record);
                return ResponseEntity.ok().body(update);
            }).orElse (ResponseEntity.notFound().build());
    }

    @DeleteMapping(path = {"deletar/{id}"})
    public ResponseEntity <?> delete(@PathVariable long id) {
        return repositorio.findById(id).map(record -> {
            repositorio.deleteById(id);
            return ResponseEntity.ok().build();
        }).orElse(ResponseEntity.notFound().build());
    }   
}