package com.goodbrowsergames.aurorawebgames.model;

import java.util.Date;
import java.util.Objects;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;

import org.hibernate.validator.constraints.NotEmpty;

@Entity
public class CategoriaJogo {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long cdCategoria;

    @NotEmpty(message = "A categoria do jogo deve ser informado!")
    private String nmCategoriaJogo;

    public Long getCdCategoria() {
        return cdCategoria;
    }

    public void setCdCategoria(Long cdCategoria) {
        this.cdCategoria = cdCategoria;
    }

    public String getNmCategoriaJogo() {
        return nmCategoriaJogo;
    }

    public void setNmCategoriaJogo(String nmCategoriaJogo) {
        this.nmCategoriaJogo = nmCategoriaJogo;
    }

    
}
